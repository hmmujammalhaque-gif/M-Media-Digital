package com.example

import android.annotation.SuppressLint
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.app.NotificationCompat
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {

    // Variable to hold WebView file choose requests callback internally
    private var fileCallback: ValueCallback<Array<Uri>>? = null

    // Register modern ActivityResult contracts for Safe visual photo/media selections
    private val fileChooserLauncher = registerForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        val results = if (uri != null) arrayOf(uri) else null
        fileCallback?.onReceiveValue(results)
        fileCallback = null
    }

    // Register ActivityResult for dynamic notifications permissions handling (Android 13+)
    private val notificationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            Toast.makeText(this, "ধন্যবাদ! বিজ্ঞপ্তির অনুমতি মঞ্জুর হয়েছে।", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(this, "বিজ্ঞপ্তির অনুমতি বাতিল করা হয়েছে। সেটিংস থেকে অন করুন কন্টাক্ট নোটিফিকেশনের জন্য।", Toast.LENGTH_LONG).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Proactively request POST_NOTIFICATIONS permission on Android 13+ devices
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            notificationPermissionLauncher.launch(android.Manifest.permission.POST_NOTIFICATIONS)
        }

        setContent {
            MyApplicationTheme {
                Surface(
                    modifier = Modifier
                        .fillMaxSize()
                        .safeDrawingPadding() // Absolute notch and edge prevention safe areas
                ) {
                    AndroidWebViewHost(this)
                }
            }
        }
    }

    // Core Jetpack Compose AndroidView wrapper hosting the WebView securely
    @SuppressLint("SetJavaScriptEnabled")
    @androidx.compose.runtime.Composable
    private fun AndroidWebViewHost(activity: MainActivity, modifier: Modifier = Modifier) {
        AndroidView(
            modifier = modifier.fillMaxSize(),
            factory = { context ->
                WebView(context).apply {
                    // Optimized high-performance configurations
                    settings.javaScriptEnabled = true
                    settings.domStorageEnabled = true
                    settings.databaseEnabled = true
                    settings.allowFileAccess = true
                    settings.allowContentAccess = true
                    settings.useWideViewPort = true
                    settings.loadWithOverviewMode = true
                    settings.mediaPlaybackRequiresUserGesture = false

                    // Sync Dark Theme in native web views if the system overrides it
                    val isDarkThemeSystem = context.resources.configuration.uiMode and 
                        android.content.res.Configuration.UI_MODE_NIGHT_MASK == 
                        android.content.res.Configuration.UI_MODE_NIGHT_YES
                    
                    // Native Javascript bridge binder
                    addJavascriptInterface(AppInterface(context), "AndroidInterface")

                    // Intercept external links vs internal content links beautifully
                    webViewClient = object : WebViewClient() {
                        override fun shouldOverrideUrlLoading(
                            view: WebView?,
                            request: WebResourceRequest?
                        ): Boolean {
                            val url = request?.url?.toString() ?: return false
                            
                            // Load internal blogger and index feeds inside WebView directly
                            if (url.startsWith("file:///android_asset/") || 
                                url.contains("blogspot.com") || 
                                url.contains("blogspot.co")
                            ) {
                                return false // Let WebView handle locally
                            }
                            
                            // Force launch external portals (such as Facebook/Instagram profiles) in System Browsers
                            try {
                                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
                                context.startActivity(intent)
                            } catch (e: Exception) {
                                Toast.makeText(context, "কোনো উপযুক্ত ব্রাউজার পাওয়া যায়নি লিংকটি ওপেন করতে!", Toast.LENGTH_SHORT).show()
                            }
                            return true // Handled externally
                        }
                    }

                    // Handle input file choices (Camera/Gallery uploads) natively
                    webChromeClient = object : WebChromeClient() {
                        override fun onShowFileChooser(
                            webView: WebView?,
                            filePathCallback: ValueCallback<Array<Uri>>?,
                            fileChooserParams: FileChooserParams?
                        ): Boolean {
                            activity.fileCallback?.onReceiveValue(null)
                            activity.fileCallback = filePathCallback
                            
                            try {
                                activity.fileChooserLauncher.launch("image/*")
                            } catch (e: Exception) {
                                activity.fileCallback?.onReceiveValue(null)
                                activity.fileCallback = null
                                return false
                            }
                            return true
                        }
                    }

                    // Core Asset Loading Command
                    loadUrl("file:///android_asset/index.html")
                }
            }
        )
    }

    // Nested Native JavaScript Interface acting as bridge to fulfill Firebase & Hardware calls
    class AppInterface(private val context: Context) {
        
        @JavascriptInterface
        fun showToast(message: String) {
            Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
        }

        @JavascriptInterface
        fun vibrate(duration: Long) {
            val vibrator = context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vibratorManager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? android.os.VibratorManager
                vibratorManager?.defaultVibrator?.vibrate(VibrationEffect.createOneShot(duration, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    vibrator?.vibrate(VibrationEffect.createOneShot(duration, VibrationEffect.DEFAULT_AMPLITUDE))
                } else {
                    @Suppress("DEPRECATION")
                    vibrator?.vibrate(duration)
                }
            }
        }

        @JavascriptInterface
        fun sendPushNotification(title: String, message: String) {
            val channelId = "m_media_channel_default"
            val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val channel = NotificationChannel(
                    channelId,
                    "M-Media Network Alerts",
                    NotificationManager.IMPORTANCE_DEFAULT
                ).apply {
                    description = "Alerts and new content notifications for creators."
                }
                notificationManager.createNotificationChannel(channel)
            }

            val builder = NotificationCompat.Builder(context, channelId)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle(title)
                .setContentText(message)
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .setAutoCancel(true)

            try {
                notificationManager.notify(102, builder.build())
            } catch (e: SecurityException) {
                Toast.makeText(context, "বিজ্ঞপ্তি প্রদানের অনুমতি পাওয়া যায়নি!", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
