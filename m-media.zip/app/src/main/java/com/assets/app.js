// M-Media Network App Logic - Fully Optimized and Persistent Offline Engine

// Initial dataset fallback to load if no local storage data is found
const defaultFeeds = [
    { 
        id: 1001, 
        isBoosted: true, 
        type: "boosted", 
        author: "কবি মোজাম্মেল হক সাগর (এডমিন)", 
        avatar: "👑", 
        title: "🔥 বিশেষ ঘোষণা এবং নতুন কবিতা প্রকাশ", 
        desc: "আমার নতুন কাব্যগ্রন্থের বাছাইকৃত কবিতাগুলো এবং 'শাহগঞ্জ প্রতিদিন' পোর্টালের সব এক্সক্লুসিভ আপডেট এখন থেকে এই একটি অফিসিয়াল অ্যাপেই লাইভ পাবেন। সবাই পোস্ট দিয়ে এংগেজমেন্ট বাড়ান!", 
        media: "https://images.unsplash.com/photo-1516414447565-b14be0adf13e?w=600", 
        likes: 1250, 
        time: "স্পন্সরড/বিজ্ঞাপন",
        comments: [
            { author: "মিজানুর রহমান", text: "অসাধারণ উদ্যোগ সাগর ভাই! কবিতাপ্রেমীদের জন্য দারুণ উপহার।" },
            { author: "ফারহানা আক্তার", text: "শুভকামনা প্রতিদিন! অ্যাপটি চমৎকার কাজ করছে।" }
        ]
    },
    { 
        id: 1002, 
        type: "shahganj", 
        author: "শাহগঞ্জ প্রতিদিন", 
        avatar: "শ", 
        title: "শাহগঞ্জ ডিজিটাল আইটি পার্কের কাজ সম্পন্ন", 
        desc: "কাঙ্ক্ষিত আইটি প্রকল্পের মূল কাজ আজ সফলভাবে সমাপ্ত হয়েছে। এলাকার বেকার যুবকদের কর্মসংস্থান সৃষ্টি করতে এই বিশেষ উদ্যোগ নেওয়া হয়েছে। বিস্তারিত জানতে আমাদের প্রফাইল সেকশন থেকে সরাসরি পোর্টাল ভিজিট করুন।", 
        media: "https://images.unsplash.com/photo-1504711434969-e33886168f5c?w=600", 
        likes: 88, 
        time: "১ ঘণ্টা আগে",
        comments: []
    },
    { 
        id: 1003, 
        type: "kobita", 
        author: "দৈনিক কবিতা প্রকাশনী", 
        avatar: "ক", 
        title: "কবিতা: জীবনের ক্যানভাস — মোজাম্মেল হক সাগর", 
        desc: "হৃদয় মাঝে লুকিয়ে আছে একলা চলার গান,\nসময়ের স্রোতে ভেসে যায় অভিমানী এক প্রাণ।\n\nঝড় আসুক আর আঁধার নামুক, থেমে যাবে না সুর,\nকবির তনুর গল্প এঁকে চলবো বহুদূর।", 
        media: "https://images.unsplash.com/photo-1457369804613-52c61a468e7d?w=600", 
        likes: 214, 
        time: "৩ ঘণ্টা আগে",
        comments: []
    }
];

const defaultChats = [
    { 
        id: 501, 
        name: "মোজাম্মেল হক সাগর (এডমিন)", 
        avatar: "👑", 
        lastMsg: "M-Media অ্যাপে আপনাকে স্বাগতম! কোনো সমস্যা হলে এখানে সরাসরি মেসেজ দিন।",
        time: "আজ ১০:১৫ AM",
        unread: 1,
        msgs: [
            { text: "আসসালামু আলাইকুম। M-Media ডিজিটাল অ্যাপে আপনাকে আন্তরিক স্বাগতম!", type: "received", time: "১০:১০ AM" },
            { text: "কোনো প্রশ্ন থাকলে, বা পোর্টালগুলোতে আপনার লেখা সাবমিট করতে চাইলে এখানে সরাসরি মেসেজ পাঠান। আমি নিজেই সাহায্য করার চেষ্টা করবো।", type: "received", time: "১০:১৫ AM" }
        ] 
    },
    { 
        id: 502, 
        name: "শাহগঞ্জ হেল্পডেস্ক", 
        avatar: "শ", 
        lastMsg: "শুভ দিন! আপনার কোনো টেকনিক্যাল প্রবলেম থাকলে বলুন।",
        time: "গতকাল",
        unread: 0,
        msgs: [
            { text: "হ্যালো! শাহগঞ্জ প্রতিদিন মিডিয়া পোর্টাল অ্যাপ সাপোর্ট ডেস্কে স্বাগতম। আপনার কি কোনো জিজ্ঞাসা আছে?", type: "received", time: "৫:২০ PM" },
            { text: "শুভ দিন! আপনার কোনো টেকনিক্যাল প্রবলেম থাকলে বলুন।", type: "received", time: "৫:২২ PM" }
        ] 
    }
];

// App Cache Variables loaded from localStorage
let currentUser = JSON.parse(localStorage.getItem('mm_user')) || null;
let coreFeeds = JSON.parse(localStorage.getItem('mm_feeds')) || defaultFeeds;
let mockChats = JSON.parse(localStorage.getItem('mm_chats')) || defaultChats;
let activeLikedPosts = JSON.parse(localStorage.getItem('mm_liked_posts')) || [];
let activeChatUserId = null;
let currentSelectedMedia = null;

// Initialize on App Load
window.addEventListener('DOMContentLoaded', () => {
    checkAuth();
    initializeTheme();
    renderFeed('all');
    renderChatList();
    initPullToRefresh();
    initializePostAutoGrowing();
    
    // Default chat notification
    updateMessengerBadge();
});

// Check if user session exists
function checkAuth() {
    const authOverlay = document.getElementById('authGateway');
    const userInitial = document.getElementById('userInitial');
    
    if (currentUser) {
        if (authOverlay) authOverlay.style.display = 'none';
        if (userInitial && currentUser.name) {
            userInitial.innerText = currentUser.name.charAt(0).toUpperCase();
        }
    } else {
        if (authOverlay) authOverlay.style.display = 'flex';
    }
}

// Google Login Mock Integration
function handleMockGoogleLogin() {
    const nameEl = document.getElementById('authName');
    const emailEl = document.getElementById('authEmail');
    
    const name = nameEl ? nameEl.value.trim() : "";
    const email = emailEl ? emailEl.value.trim() : "";
    
    if (!name || !email) { 
        alert("দয়া করে আপনার নাম এবং জিমেইল প্রদান করুন!"); 
        return; 
    }
    
    // Basic verification
    if (!email.includes('@')) {
        alert("দয়া করে একটি সঠিক জিমেইল এড্রেস লিখুন!");
        return;
    }

    currentUser = { name: name, email: email };
    localStorage.setItem('mm_user', JSON.stringify(currentUser));
    checkAuth();
    
    // Visual Notification
    showNotification("সফলভাবে লগইন করা হয়েছে!");
}

// Logout Engine
function handleLogout() {
    const confirmLogout = confirm("আপনি কি নিশ্চিতভাবে এই প্রোফাইল থেকে লগ আউট করতে চান?");
    if (confirmLogout) {
        localStorage.removeItem('mm_user');
        currentUser = null;
        document.getElementById('authGateway').style.display = 'flex';
        // Reset local input placeholders
        document.getElementById('authName').value = '';
        document.getElementById('authEmail').value = '';
        switchPanel('home');
    }
}

// Pull-to-refresh Gesture Implementation
let touchStartY = 0;
let touchMovedY = 0;
const refreshThreshold = 80; // distance to drag in px
const ptrElement = document.getElementById('pull-to-refresh');
const swipeArea = document.getElementById('swipe-area');

function initPullToRefresh() {
    if (!swipeArea || !ptrElement) return;

    window.addEventListener('touchstart', (e) => {
        // Only trigger at top of scroll
        if (window.scrollY === 0) {
            touchStartY = e.touches[0].clientY;
        } else {
            touchStartY = 0;
        }
    }, { passive: true });

    window.addEventListener('touchmove', (e) => {
        if (touchStartY === 0) return;
        
        const currentY = e.touches[0].clientY;
        touchMovedY = currentY - touchStartY;
        
        if (touchMovedY > 0) {
            // User is scrolling down at the top of the viewport
            e.preventDefault(); // prevent native reload until snapped
            const pullVal = Math.min(touchMovedY * 0.4, refreshThreshold);
            swipeArea.style.transform = `translateY(${pullVal}px)`;
            ptrElement.style.transform = `translateY(${-60 + pullVal}px)`;
            ptrElement.style.opacity = (pullVal / refreshThreshold);
            ptrElement.classList.add('pulling');
        }
    }, { passive: false });

    window.addEventListener('touchend', () => {
        if (touchStartY === 0) return;
        
        if (touchMovedY >= refreshThreshold) {
            // Trigger Refresh Task
            triggerRefreshTask();
        } else {
            // Snap back
            resetPullToRefresh();
        }
        touchStartY = 0;
        touchMovedY = 0;
    });
}

function triggerRefreshTask() {
    ptrElement.style.transform = 'translateY(0px)';
    ptrElement.style.opacity = '1';
    swipeArea.style.transform = 'translateY(40px)';
    
    // Simulate real network fetch
    setTimeout(() => {
        // Mock add a fresh feed post if not already exists
        const freshId = Date.now();
        const hasFreshPost = coreFeeds.some(f => f.id === 9999);
        
        if (!hasFreshPost) {
            const freshPost = {
                id: 9999,
                type: "shahganj",
                author: "শাহগঞ্জ প্রতিদিন নিউজ ডেক্স",
                avatar: "শ",
                title: "🔴 ব্রেকিং: শাহগঞ্জ মোড়ে আধুনিক লাইটিং প্রকল্পের উদ্বোধন",
                desc: "আজ সন্ধ্যায় আনুষ্ঠানিকভাবে দৃষ্টিনন্দন সড়কবাতি স্থাপনের কাজ সম্পূর্ণ হয়ে উদ্বোধন হতে যাচ্ছে। উৎসুক জনতারা আনন্দ প্রকাশ করেছেন ও এলাকার নিরাপত্তা অনেকাংশে বৃদ্ধি পাবে বলে জানিয়েছেন মেয়র।",
                media: "https://images.unsplash.com/photo-1477959858617-67f85cf4f1df?w=600",
                likes: 42,
                time: "এইমাত্র রিফ্রেশ করা হয়েছে",
                comments: []
            };
            coreFeeds.unshift(freshPost);
            localStorage.setItem('mm_feeds', JSON.stringify(coreFeeds));
        }

        renderFeed('all');
        resetPullToRefresh();
        showNotification("আপডেট হওয়া কন্টেন্ট রিফ্রেশ করা হয়েছে!");
    }, 1500);
}

function resetPullToRefresh() {
    ptrElement.style.transform = 'translateY(-60px)';
    ptrElement.style.opacity = '0';
    ptrElement.classList.remove('pulling');
    swipeArea.style.transform = 'translateY(0px)';
}

// Light & Dark Theme Controller
function initializeTheme() {
    const savedTheme = localStorage.getItem('mm_theme') || 'light';
    const htmlNode = document.documentElement;
    htmlNode.setAttribute('data-theme', savedTheme);
    
    const themeIcon = document.querySelector('#theme-toggle-btn i');
    if (themeIcon) {
        themeIcon.className = savedTheme === 'dark' ? 'fas fa-sun' : 'fas fa-moon';
    }
}

function toggleTheme() {
    const htmlNode = document.documentElement;
    const currentTheme = htmlNode.getAttribute('data-theme') || 'light';
    const nextTheme = currentTheme === 'dark' ? 'light' : 'dark';
    
    htmlNode.setAttribute('data-theme', nextTheme);
    localStorage.setItem('mm_theme', nextTheme);
    
    const themeIcon = document.querySelector('#theme-toggle-btn i');
    if (themeIcon) {
        themeIcon.className = nextTheme === 'dark' ? 'fas fa-sun' : 'fas fa-moon';
    }
    
    showNotification(nextTheme === 'dark' ? 'ডার্ক মোড সক্রিয় হয়েছে!' : 'লাইট মোড সক্রিয় হয়েছে!');
}

// Responsive Router Switching Panels
function switchPanel(panelId, clickElement = null) {
    // Hide active panels and links
    document.querySelectorAll('.app-panel').forEach(panel => {
        panel.classList.remove('active');
    });

    document.querySelectorAll('.nav-link').forEach(link => {
        link.classList.remove('active');
    });

    const targetPanel = document.getElementById(`${panelId}-panel`);
    if (targetPanel) {
        targetPanel.classList.add('active');
    }

    if (clickElement) {
        clickElement.classList.add('active');
    } else {
        // Sync bottom nav links if action was triggered from somewhere else
        const botLinks = document.querySelectorAll('.bottom-nav .nav-link');
        if (panelId === 'home' && botLinks[0]) botLinks[0].classList.add('active');
        if (panelId === 'messages' && botLinks[1]) botLinks[1].classList.add('active');
        if (panelId === 'profile' && botLinks[2]) botLinks[2].classList.add('active');
    }

    // Toggle specific secondary UI headers depending on section
    const homeTabs = document.getElementById('home-tabs');
    if (homeTabs) {
        homeTabs.style.display = (panelId === 'home') ? 'flex' : 'none';
    }

    // Dynamic Graph update if user loads Dashboard
    if (panelId === 'dashboard') {
        setTimeout(() => {
            updateAnalyticsTimeframe('7d', document.querySelector('.filter-btn'));
        }, 100);
    }
    
    window.scrollTo({ top: 0, behavior: 'smooth' });
}

// Media Attachment Attachment Mock (Image / Video Uploads)
function triggerMediaMock(type) {
    let mockUrl = "";
    if (type === 'image') {
        mockUrl = "https://images.unsplash.com/photo-1481627834876-b7833e8f5570?w=600";
    } else if (type === 'video') {
        mockUrl = "video"; // dynamic mock visual tag
    } else if (type === 'chat-image') {
        mockUrl = "https://images.unsplash.com/photo-1543002588-bfa74002ed7e?w=600";
    }

    if (type === 'chat-image' && activeChatUserId) {
        // Attach image direct to active chat
        const targetChat = mockChats.find(c => c.id === activeChatUserId);
        if (targetChat) {
            targetChat.msgs.push({
                text: "",
                media: mockUrl,
                type: "sent",
                time: getFormattedCurrentTime()
            });
            targetChat.lastMsg = "📷 ফটো সেন্ড করেছেন";
            localStorage.setItem('mm_chats', JSON.stringify(mockChats));
            renderChatFlow(activeChatUserId);
            
            // Bot replies to the photo
            setTimeout(() => {
                triggerBotAutoReply("ফটো পেয়েছেন");
            }, 1200);
        }
        return;
    }

    // Home post attachment logic
    currentSelectedMedia = mockUrl;
    const mediaPreview = document.getElementById('media-attachment-preview');
    const previewImg = document.getElementById('attached-media-img');
    const actionBtns = document.querySelector('.attachment-options');

    if (mediaPreview && previewImg) {
        if (type === 'image') {
            previewImg.src = mockUrl;
            mediaPreview.style.display = "block";
            showNotification("ফটো সিলেক্ট করা হয়েছে!");
        } else if (type === 'video') {
            previewImg.src = "https://images.unsplash.com/photo-1492691527719-9d1e07e534b4?w=600"; // display video banner holder
            mediaPreview.style.display = "block";
            showNotification("ভিডিও সিলেক্ট করা হয়েছে!");
        }
    }
}

function clearMediaAttachment() {
    currentSelectedMedia = null;
    const mediaPreview = document.getElementById('media-attachment-preview');
    if (mediaPreview) mediaPreview.style.display = 'none';
}

// Auto-Grow Post text-area adaptively
function initializePostAutoGrowing() {
    const postTextarea = document.getElementById('userPostInput');
    if (!postTextarea) return;
    postTextarea.addEventListener('input', function() {
        this.style.height = 'auto';
        this.style.height = (this.scrollHeight) + 'px';
    });
}

// Create New Post Function execution
function executeUserPost() {
    const postTextarea = document.getElementById('userPostInput');
    const descText = postTextarea ? postTextarea.value.trim() : "";

    if (!descText && !currentSelectedMedia) {
        alert("দয়া করে আপনার মনে কি আছে কিছু লিখুন অথবা ফটো/ভিডিও যুক্ত করুন!");
        return;
    }

    const brandName = currentUser ? currentUser.name : "ইউজার";
    const initial = currentUser ? currentUser.name.charAt(0).toUpperCase() : "U";

    const newPost = {
        id: Date.now(),
        type: "user",
        author: brandName,
        avatar: initial,
        title: "",
        desc: descText,
        media: currentSelectedMedia,
        likes: 0,
        time: "এইমাত্র",
        comments: []
    };

    coreFeeds.unshift(newPost);
    localStorage.setItem('mm_feeds', JSON.stringify(coreFeeds));

    // Cleanup input
    if (postTextarea) {
        postTextarea.value = "";
        postTextarea.style.height = "auto";
    }
    clearMediaAttachment();
    
    // Refresh page
    renderFeed('all');
    showNotification("পোস্টটি সফলভাবে পাবলিশ করা হয়েছে!");
}

// Render dynamic Feed Posts
function renderFeed(filterType = 'all') {
    const container = document.getElementById('dynamic-feed-container');
    if (!container) return;
    
    container.innerHTML = '';
    let filteredData = [...coreFeeds];
    
    if (filterType === 'boosted') {
        filteredData = coreFeeds.filter(feed => feed.isBoosted);
    }

    if (filteredData.length === 0) {
        container.innerHTML = `
            <div class="feed-card" style="text-align:center; padding: 30px; color: var(--text-secondary);">
                <i class="fas fa-folder-open" style="font-size:36px; margin-bottom:8px; opacity:0.6;"></i>
                <p>কোনো কন্টেন্ট খুঁজে পাওয়া যায়নি।</p>
            </div>
        `;
        return;
    }

    filteredData.forEach(feed => {
        const isLiked = activeLikedPosts.includes(feed.id);
        const card = document.createElement('div');
        card.id = `feed-id-${feed.id}`;
        card.className = `feed-card ${feed.isBoosted ? 'boosted-card' : ''}`;
        
        // Populate layout
        let commentsHTML = '';
        if (feed.comments && feed.comments.length > 0) {
            commentsHTML = `
                <div class="comments-section" id="comments-${feed.id}">
                    ${feed.comments.map(c => `
                        <div class="comment-item">
                            <strong>${c.author}:</strong> <span>${c.text}</span>
                        </div>
                    `).join('')}
                </div>
            `;
        } else {
            commentsHTML = `<div class="comments-section empty" id="comments-${feed.id}"></div>`;
        }

        card.innerHTML = `
            <div class="card-header">
                <div class="card-author-info">
                    <div class="source-avatar" style="background: ${feed.isBoosted ? 'linear-gradient(135deg, #f59e0b, #e1306c)' : 'var(--fb-blue)'}">${feed.avatar}</div>
                    <div class="source-meta">
                        <h4>${feed.author} ${feed.isBoosted ? '<span class="badge-boosted">ম্যানেজার স্পেশাল</span>' : ''}</h4>
                        <span>${feed.time}</span>
                    </div>
                </div>
                <button class="more-btn" onclick="openPostMenu(${feed.id})"><i class="fas fa-ellipsis-h"></i></button>
            </div>
            
            <div class="card-content">
                ${feed.title ? `<strong>${feed.title}</strong>` : ''}
                <p>${feed.desc}</p>
            </div>
            
            ${feed.media ? `
                <div class="card-media">
                    <img src="${feed.media}" alt="Feed Media Attachment">
                </div>
            ` : ''}
            
            <div class="reactions-counter">
                <span class="likes-pill">
                    <i class="fas fa-thumbs-up" style="color:var(--fb-blue);"></i> 
                    <span id="like-count-${feed.id}">${feed.likes}</span>
                </span>
                <span style="cursor:pointer;" onclick="focusCommentInput(${feed.id})">
                    <span id="comment-count-${feed.id}">${feed.comments ? feed.comments.length : 0}</span> মন্তব্য
                </span>
            </div>
            
            <div class="feed-actions">
                <button class="action-button ${isLiked ? 'liked' : ''}" onclick="toggleLikePost(${feed.id}, this)">
                    <i class="${isLiked ? 'fas' : 'far'} fa-thumbs-up"></i> লাইক
                </button>
                <button class="action-button" onclick="focusCommentInput(${feed.id})">
                    <i class="far fa-comment"></i> মন্তব্য
                </button>
                <button class="action-button" onclick="sharePost(${feed.id})">
                    <i class="far fa-share-square"></i> শেয়ার
                </button>
            </div>

            <!-- Comment Input drawer interface -->
            <div class="comment-composer-box">
                ${commentsHTML}
                <div class="comment-input-row">
                    <input type="text" id="comment-field-${feed.id}" class="comment-inline-field" placeholder="মন্তব্য লিখুন..." onkeypress="handleCommentEnter(event, ${feed.id})">
                    <button class="btn-send-comment" onclick="submitInlineComment(${feed.id})"><i class="fas fa-paper-plane"></i></button>
                </div>
            </div>
        `;
        container.appendChild(card);
    });
}

// Filter Feed Categories
function filterFeed(type, chipEl) {
    document.querySelectorAll('#home-tabs .chip').forEach(chip => {
        chip.classList.remove('active');
    });
    if (chipEl) chipEl.classList.add('active');
    renderFeed(type);
}

// Persisted Liking mechanism
function toggleLikePost(postId, buttonEl) {
    const feedIndex = coreFeeds.findIndex(f => f.id === postId);
    if (feedIndex === -1) return;

    const likeSpan = document.getElementById(`like-count-${postId}`);
    if (activeLikedPosts.includes(postId)) {
        // Dislike action
        activeLikedPosts = activeLikedPosts.filter(id => id !== postId);
        coreFeeds[feedIndex].likes = Math.max(0, coreFeeds[feedIndex].likes - 1);
        
        buttonEl.classList.remove('liked');
        const icon = buttonEl.querySelector('i');
        if (icon) icon.className = "far fa-thumbs-up";
        if (likeSpan) likeSpan.innerText = coreFeeds[feedIndex].likes;
    } else {
        // Like action
        activeLikedPosts.push(postId);
        coreFeeds[feedIndex].likes += 1;
        
        buttonEl.classList.add('liked');
        const icon = buttonEl.querySelector('i');
        if (icon) icon.className = "fas fa-thumbs-up";
        if (likeSpan) likeSpan.innerText = coreFeeds[feedIndex].likes;
        
        // Sync professional dashboard counter dynamically
        syncDashboardLikes();
    }
    
    localStorage.setItem('mm_liked_posts', JSON.stringify(activeLikedPosts));
    localStorage.setItem('mm_feeds', JSON.stringify(coreFeeds));
}

function syncDashboardLikes() {
    const dashboardLikes = document.getElementById('dashLikes');
    if (dashboardLikes) {
        // Total default likes + dynamic liked count minus removed likes
        let sumLikes = coreFeeds.reduce((acc, f) => acc + f.likes, 0);
        dashboardLikes.innerText = sumLikes;
    }
}

// Post Settings Menu Modal
function openPostMenu(postId) {
    const isUserPost = coreFeeds.find(f => f.id === postId)?.type === 'user';
    let menuOptions = ["রিপোর্ট পোস্ট", "কপি লিংক"];
    if (isUserPost) {
        menuOptions.unshift("পোস্ট ডিলিট করুন");
    }

    const userChoice = confirm("পোস্ট অপশন সমূহ:\n\n" + menuOptions.map((opt, i) => `${i+1}. ${opt}`).join('\n') + "\n\n(ডিলিট বা রিপোর্ট নিশ্চিত করতে ক্লিক করুন)");
    
    if (userChoice) {
        if (isUserPost) {
            coreFeeds = coreFeeds.filter(f => f.id !== postId);
            localStorage.setItem('mm_feeds', JSON.stringify(coreFeeds));
            renderFeed('all');
            showNotification("পোস্টটি সফলভাবে মুছে ফেলা হয়েছে!");
        } else {
            showNotification("পোস্টের লিংক কপি করা হয়েছে!");
        }
    }
}

// Inline Comment Submission Persisted
function handleCommentEnter(e, postId) {
    if (e.key === 'Enter') {
        submitInlineComment(postId);
    }
}

function focusCommentInput(postId) {
    const field = document.getElementById(`comment-field-${postId}`);
    if (field) {
        field.focus();
    }
}

function submitInlineComment(postId) {
    const field = document.getElementById(`comment-field-${postId}`);
    const text = field ? field.value.trim() : "";
    if (!text) return;

    const feedIndex = coreFeeds.findIndex(f => f.id === postId);
    if (feedIndex === -1) return;

    const commentator = currentUser ? currentUser.name : "নামবিহীন পাঠক";
    const comment = { author: commentator, text: text };
    
    if (!coreFeeds[feedIndex].comments) {
        coreFeeds[feedIndex].comments = [];
    }

    coreFeeds[feedIndex].comments.push(comment);
    localStorage.setItem('mm_feeds', JSON.stringify(coreFeeds));

    // Dynamic append to avoid complete rerender reload
    const commentsBox = document.getElementById(`comments-${postId}`);
    if (commentsBox) {
        commentsBox.classList.remove('empty');
        const cRow = document.createElement('div');
        cRow.className = 'comment-item';
        cRow.innerHTML = `<strong>${commentator}:</strong> <span>${text}</span>`;
        commentsBox.appendChild(cRow);
    }

    const cCountSpan = document.getElementById(`comment-count-${postId}`);
    if (cCountSpan) {
        cCountSpan.innerText = coreFeeds[feedIndex].comments.length;
    }

    field.value = '';
    showNotification("আপনার মন্তব্য যুক্ত হয়েছে!");
}

// Share post mock
function sharePost(postId) {
    if (navigator.share) {
        navigator.share({
            title: 'M-Media Digital Network',
            text: 'মজার মজার সব বাংলা কবিতা ও শাহগঞ্জ প্রতিদিনের আপডেট দেখুন আমাদের মোবাইল অ্যাপে!',
            url: window.location.href
        }).catch(err => {
            console.log(err);
        });
    } else {
        alert("পোস্টের লিংক আপনার ক্লিপবোর্ডে কপি করা হয়েছে!");
    }
}

// MESSENGER ENGAGEMENT CORE ENGINE 
function renderChatList() {
    const chatListTarget = document.getElementById('chat-list-target');
    if (!chatListTarget) return;

    chatListTarget.innerHTML = '';
    
    mockChats.forEach(chat => {
        const itemRow = document.createElement('div');
        itemRow.className = 'chat-list-item';
        itemRow.setAttribute('onclick', `openChatRoom(${chat.id})`);
        
        itemRow.innerHTML = `
            <div class="chat-item-left">
                <div class="source-avatar" style="background: linear-gradient(135deg, #0045a3, #1877f2)">${chat.avatar}</div>
                <div class="chat-meta">
                    <h4>${chat.name}</h4>
                    <p>${chat.lastMsg}</p>
                </div>
            </div>
            <div class="chat-item-right">
                <span class="chat-time">${chat.time}</span>
                ${chat.unread > 0 ? `<span class="chat-badge">${chat.unread}</span>` : ''}
            </div>
        `;
        chatListTarget.appendChild(itemRow);
    });
}

function updateMessengerBadge() {
    const totalUnread = mockChats.reduce((acc, c) => acc + c.unread, 0);
    const badgeCount = document.getElementById('badge-count');
    if (badgeCount) {
        if (totalUnread > 0) {
            badgeCount.innerText = totalUnread;
            badgeCount.style.display = 'flex';
        } else {
            badgeCount.style.display = 'none';
        }
    }
}

function openChatRoom(chatId) {
    activeChatUserId = chatId;
    const targetChat = mockChats.find(c => c.id === chatId);
    if (!targetChat) return;

    // Reset unread status
    targetChat.unread = 0;
    localStorage.setItem('mm_chats', JSON.stringify(mockChats));
    renderChatList();
    updateMessengerBadge();

    // Populate active room headers
    document.getElementById('chatWindowAvatar').innerText = targetChat.avatar;
    document.getElementById('chatWindowName').innerText = targetChat.name;

    // Load messages
    renderChatFlow(chatId);

    // Slide open drawer
    document.getElementById('activeChatWindow').style.display = 'flex';
}

function renderChatFlow(chatId) {
    const flowContainer = document.getElementById('chatMessageFlow');
    const targetChat = mockChats.find(c => c.id === chatId);
    if (!flowContainer || !targetChat) return;

    flowContainer.innerHTML = '';
    targetChat.msgs.forEach(msg => {
        const bubble = document.createElement('div');
        bubble.className = `msg-bubble ${msg.type === 'sent' ? 'msg-sent' : 'msg-received'}`;
        
        let visualMediaHtml = '';
        if (msg.media) {
            visualMediaHtml = `<img src="${msg.media}" alt="Attached media">`;
        }

        bubble.innerHTML = `
            ${visualMediaHtml}
            ${msg.text ? `<p>${msg.text}</p>` : ''}
        `;
        flowContainer.appendChild(bubble);
    });
    
    // Auto Scroll to bottom
    setTimeout(() => {
        flowContainer.scrollTop = flowContainer.scrollHeight;
    }, 50);
}

function closeChat() {
    document.getElementById('activeChatWindow').style.display = 'none';
    activeChatUserId = null;
}

function handleChatEnter(e) {
    if (e.key === 'Enter') {
        dispatchLiveMessage();
    }
}

function dispatchLiveMessage() {
    const inputField = document.getElementById('chatInputField');
    const msgText = inputField ? inputField.value.trim() : "";
    if (!msgText && !currentSelectedMedia) return;

    const targetChat = mockChats.find(c => c.id === activeChatUserId);
    if (!targetChat) return;

    const timeString = getFormattedCurrentTime();

    // Enqueue message
    targetChat.msgs.push({
        text: msgText,
        type: "sent",
        time: timeString
    });

    targetChat.lastMsg = msgText || "📷 ফটো সেন্ড করেছেন";
    targetChat.time = "আজ " + timeString;
    
    // Save state
    localStorage.setItem('mm_chats', JSON.stringify(mockChats));
    
    // Reset Composer and view update
    if (inputField) inputField.value = '';
    renderChatFlow(activeChatUserId);
    renderChatList();

    // Smart Conversational Response Scheduler
    setTimeout(() => {
        triggerBotAutoReply(msgText);
    }, 1200);
}

// Intelligent Bangla Chatbot Responder based on natural keywords
function triggerBotAutoReply(userQueryText) {
    if (!activeChatUserId) return;
    const targetChat = mockChats.find(c => c.id === activeChatUserId);
    if (!targetChat) return;

    let responseString = "";
    const cleanQuery = userQueryText.toLowerCase();

    // Conversation routing logic
    if (activeChatUserId === 501) { // Mozoomel Sagar responses
        if (cleanQuery.includes("কবিতা") || cleanQuery.includes("সাহিত্য") || cleanQuery.includes("বই")) {
            responseString = "ধন্যবাদ আমার লেখা নিয়ে আগ্রহের জন্য! আমার নতুন বই 'শব্দের ক্যানভাস' নিয়ে খুব শীঘ্রই শাহগঞ্জ প্রেস ক্লাবে একটি পাঠ উন্মোচন হবে। আপনি সেখানে আমন্ত্রিত!";
        } else if (cleanQuery.includes("কেমন" || cleanQuery.includes("ভাল") || cleanQuery.includes("ভালো"))) {
            responseString = "আলহামদুলিল্লাহ্‌, আমি খুব ভালো আছি! আশা করি আপনিও ভালো আছেন। আমাদের M-Media এর এই চমৎকার নতুন প্ল্যাটফর্মটি আপনার কেমন লাগছে?";
        } else if (cleanQuery.includes("শাহগঞ্জ") || cleanQuery.includes("নিউজ") || cleanQuery.includes("পোর্টাল")) {
            responseString = "শাহগঞ্জ প্রতিদিনে আপনার এলাকার যেকোনো সমস্যা বা সুসংবাদের খতিয়ান ছবিসহ আমাদের ডেক্সে পাঠান, আমরা তা ফ্রন্ট-পেজে পাবলিশ করব ইনশাআল্লাহ্‌!";
        } else if (cleanQuery.includes("ফটো")) {
            responseString = "খুবই আকর্ষণীয় ফটো! শুভকামনা রইল আপনার সুন্দর দৃষ্টিভঙ্গির জন্য।";
        } else {
            responseString = "আপনার মেসেজের জন্য ধন্যবাদ। আমি বর্তমানে একটি নতুন কবিতা আবৃত্তি রেকর্ডিং করছি। আমি খুব দ্রুতই আপনার মেসেজ পড়ে বিস্তারিত উত্তর পাঠাব জিজাকিল্লাহ!";
        }
    } else { // Tech support desk
        if (cleanQuery.includes("লগইন") || cleanQuery.includes("অ্যাকাউন্ট") || cleanQuery.includes("জিমেইল")) {
            responseString = "জিমেইল লগইন সমস্যা দূরীকরণে দয়া করে ইন্টারনেট কানেকশন চেক করুন ও ব্যাকগ্রাউন্ড থেকে অ্যাপটি একবার রিস্টার্ট করুন।";
        } else if (cleanQuery.includes("রিফ্রেশ") || cleanQuery.includes("ফিড")) {
            responseString = "ফিড রিফ্রেশ করতে স্ক্রিনের ওপর থেকে নিচের দিকে জোরে টান দিন (Pull) করে ছেড়ে দিন, স্বয়ংক্রিয়ভাবে নতুন খবরের আপডেট লোড হবে।";
        } else {
            responseString = "আমরা আপনার মেসেজটি গ্রহণ করেছি। আমাদের একজন প্রতিনিধি দ্রুত টেকনিক্যাল সহায়তার জন্য আপনার সাথে যোগাযোগ করবেন। আমাদের সাথে থাকার জন্য ধন্যবাদ!";
        }
    }

    const replyTime = getFormattedCurrentTime();
    
    targetChat.msgs.push({
        text: responseString,
        type: "received",
        time: replyTime
    });

    targetChat.lastMsg = responseString;
    targetChat.time = "আজ " + replyTime;

    // Save and Render
    localStorage.setItem('mm_chats', JSON.stringify(mockChats));
    renderChatFlow(activeChatUserId);
    renderChatList();
    
    // Play vibration feel if on Android WebView bridge
    if (window.AndroidInterface && window.AndroidInterface.vibrate) {
        window.AndroidInterface.vibrate(80);
    }
}

// PRO PREMIUM ANALYTICS CONTROLLER
function updateAnalyticsTimeframe(timeframe, btnEl) {
    // Styling toggle
    const filterBtns = document.querySelectorAll('.dash-time-filter .filter-btn');
    if (filterBtns) {
        filterBtns.forEach(btn => btn.classList.remove('active'));
    }
    if (btnEl) btnEl.classList.add('active');

    // Stats scale datasets
    const timelineData = {
        '7d': { reach: "১,৫৫০", engagement: "৯২৪", likes: "৪৫০" },
        '30d': { reach: "৭,৮৪০", engagement: "৪,১১০", likes: "২,১৩০" },
        'all': { reach: "৫৬,২৩০", engagement: "৩১,৪৯০", likes: "১৫,৪০০" }
    };

    const metrics = timelineData[timeframe] || timelineData['7d'];
    
    // Update labels beautifully
    const impressEl = document.getElementById('dashImpressions');
    const enggEl = document.getElementById('dashEngagement');
    const likesEl = document.getElementById('dashLikes');

    if (impressEl) impressEl.innerText = metrics.reach;
    if (enggEl) enggEl.innerText = metrics.engagement;
    if (likesEl) likesEl.innerText = metrics.likes;

    // Morph SVG Chart path dynamically for a fluid high-end look
    const reachLine = document.getElementById('chart-reach-line');
    const reachArea = document.getElementById('chart-reach-area');
    const enggLine = document.getElementById('chart-engg-line');
    const enggArea = document.getElementById('chart-engg-area');

    if (timeframe === '30d') {
        if (reachLine) reachLine.setAttribute('d', 'M 0,120 Q 120,40 240,60 T 420,50 T 500,10');
        if (reachArea) reachArea.setAttribute('d', 'M 0,120 Q 120,40 240,60 T 420,50 T 500,10 L 500,160 L 0,160 Z');
        if (enggLine) enggLine.setAttribute('d', 'M 0,140 Q 110,80 220,100 T 410,70 T 500,30');
        if (enggArea) enggArea.setAttribute('d', 'M 0,140 Q 110,80 220,100 T 410,70 T 500,30 L 500,160 L 0,160 Z');
    } else if (timeframe === 'all') {
        if (reachLine) reachLine.setAttribute('d', 'M 0,150 Q 80,10 210,120 T 430,10 T 500,10');
        if (reachArea) reachArea.setAttribute('d', 'M 0,150 Q 80,10 210,120 T 430,10 T 500,10 L 500,160 L 0,160 Z');
        if (enggLine) enggLine.setAttribute('d', 'M 0,160 Q 90,40 220,140 T 390,40 T 500,20');
        if (enggArea) enggArea.setAttribute('d', 'M 0,160 Q 90,40 220,140 T 390,40 T 500,20 L 500,160 L 0,160 Z');
    } else { // 7 days baseline
        if (reachLine) reachLine.setAttribute('d', 'M 0,130 Q 100,60 200,90 T 400,20 T 500,50');
        if (reachArea) reachArea.setAttribute('d', 'M 0,130 Q 100,60 200,90 T 400,20 T 500,50 L 500,160 L 0,160 Z');
        if (enggLine) enggLine.setAttribute('d', 'M 0,150 Q 80,110 180,120 T 380,60 T 500,80');
        if (enggArea) enggArea.setAttribute('d', 'M 0,150 Q 80,110 180,120 T 380,60 T 500,80 L 500,160 L 0,160 Z');
    }
}

// Utility Helper functions
function getFormattedCurrentTime() {
    const d = new Date();
    let hrs = d.getHours();
    let mins = d.getMinutes();
    const ampm = hrs >= 12 ? 'PM' : 'AM';
    hrs = hrs % 12;
    hrs = hrs ? hrs : 12;
    mins = mins < 10 ? '0' + mins : mins;
    return `${hrs}:${mins} ${ampm}`;
}

// Dynamic Floating Toast Notifications
function showNotification(message) {
    const notificationContainer = document.createElement('div');
    notificationContainer.className = 'floating-toast';
    notificationContainer.innerHTML = `<i class="fas fa-check-circle" style="color: #10b981; margin-right: 8px;"></i> ${message}`;
    
    // Inject styles dynamically to avoid style file bloat
    Object.assign(notificationContainer.style, {
        position: 'fixed',
        bottom: '84px',
        left: '50%',
        transform: 'translateX(-50%) translateY(20px)',
        background: 'rgba(5, 5, 5, 0.85)',
        backdropFilter: 'blur(8px)',
        color: '#ffffff',
        padding: '10px 20px',
        borderRadius: '30px',
        fontSize: '13.5px',
        fontFamily: "'Hind Siliguri', sans-serif",
        fontWeight: 'bold',
        zIndex: '99999',
        boxShadow: '0 4px 12px rgba(0,0,0,0.15)',
        opacity: '0',
        transition: 'all 0.3s cubic-bezier(0.18, 0.89, 0.32, 1.28)',
        display: 'flex',
        alignItems: 'center',
        whiteSpace: 'nowrap'
    });

    document.body.appendChild(notificationContainer);
    
    // Animate In
    setTimeout(() => {
        notificationContainer.style.opacity = '1';
        notificationContainer.style.transform = 'translateX(-50%) translateY(0)';
    }, 50);

    // Fade Out
    setTimeout(() => {
        notificationContainer.style.opacity = '0';
        notificationContainer.style.transform = 'translateX(-50%) translateY(20px)';
        setTimeout(() => {
            if (notificationContainer.parentNode) {
                notificationContainer.parentNode.removeChild(notificationContainer);
            }
        }, 300);
    }, 2500);
}
